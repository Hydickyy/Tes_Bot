<p align="center">
<img src="https://telegra.ph/file/8c988b0bd80b582673019.jpg" alt="LEXXY BOT" width="200"/>

<p align="center">
    <a href="https://Lexxy24.github.io">
        <img
            src="https://readme-typing-svg.herokuapp.com?size=15&width=280&lines=Created+By+Lexxy+Official+🌐"
            alt="Lexxy Official"
        />
    </a>
</p>

# BOTV13
## Heroku Buildpack

Click the deploy icon below !

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/Lexxy24/v13)

```bash
 > heroku/nodejs
 > https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest
 > https://github.com/clhuang/heroku-buildpack-webp-binaries.git
```

## Termux
```bash
> pkg install bash
> pkg install nodejs
> pkg install libwebp
> pkg install git
> pkg install imagemagick
> pkg install ffmpeg
> termux-setup-storage
> cd /sdcard/v13
> git clone https://github.com/Lexxy24/v13.git
> cd v13
> git clone https://github.com/Lexxy24/node_modules
> npm start
```

## settings
Edit Nomor Owner DLL `'./settings/setting.json'`

```ts
{
"BotName":"Dicky BOTz",
"OwnerNumber":"6282118862838",
"OwnerName":"Dicky Ganz",

"GithubOwner":"https://github.com/Hydickyy",
"YoutubeOwner":"https://youtube.com/c/Hydickyy",
"GroupOwner":"https://chat.whatsapp.com/JLbp9oDHKfHFyMTc4Xk6NV<"
}
```

# My Sosial
- [Group ](https://chat.whatsapp.com/JLbp9oDHKfHFyMTc4Xk6NV
- [YouTube ](https://youtube.com/c/Hydickyy)
- [Whatsapp ](https://wa.me/6282118862838)
